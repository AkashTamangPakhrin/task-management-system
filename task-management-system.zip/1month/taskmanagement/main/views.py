from django.shortcuts import render,redirect
from .models import Project
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth.forms import UserCreationForm,PasswordChangeForm 
from django.http import HttpResponse
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.template.loader import render_to_string
from datetime import datetime
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password

# Create your views here.
@login_required(login_url='log_in')
def home(request):
    return render(request,'main/home.html')

def contact(request):
    return render(request,'main/contact.html')

def about(request):
    return render(request,'main/about.html')

def form(request):
    if request.method=='POST':
        name=request.POST.get('name')
        age=request.POST.get('age')
        email=request.POST.get('email')
        message=request.POST.get('message')
        date=datetime.now()

        Project.objects.create(name=name,age=age,email=email,message=message)
        
        subject = "python training"
        message = render_to_string('main/msg.html',{'name':name,'date':date})
        from_email = 'tamangakashpakhrin@gmail.com'
        recipient_list = [email]
        
        send_mail(subject,message,from_email,recipient_list,fail_silently=False)
        messages.success(request,f"Hi {name} successfully registered check your mail!!!")
        return redirect("form")
    
    return render(request,'main/form.html')

def track(request):
    return render(request,'main/track.html')

def update(request):
    data=Project.objects.filter(Isdelete=False)
    return render(request,'main/update.html',{'data': data})

def create(request):
    return render(request,'main/create.html')

def search_form(request):
    if request.method=='POST':
        searched=request.POST['searched']     
        finds=Project.objects.filter(Q(name__icontains=searched)| Q(message__icontains=searched))

    return render(request,'main/search.html',{'finds':finds})

def delete_data(request,id):
    pro=Project.objects.get(id=id)
    pro.Isdelete=True
    pro.save()
    return redirect('update')

def edit(request,id):
    data=Project.objects.get(id=id)
    if request.method=='POST':
       
        pro=Project.objects.get(id=id)
        pro.name=request.POST.get('name')
        pro.age=request.POST.get('age')
        pro.email=request.POST.get('email')
        pro.message=request.POST.get('message')
        pro.save()
        messages.success(request,"Successfully Updated!!!")
        return redirect('update')
    return render(request,'main/edit.html',{'data': data})

def aboutus(request):
    return render(request,'main/aboutus.html')

def register(request):
    if request.method == 'POST':
        name = request.POST['name']
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password1 = request.POST['password1']
        if password == password1:
            if User.objects.filter(username=username).exists():
                messages.info(request, f'Hi, {name} your username already exists')
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.info(request, f'Hi, {name} your email already exists')
            else:
                hashed_password = make_password(password)  # Hashing the password
                User.objects.create(first_name=name, username=username, email=email, password=hashed_password)
                messages.success(request, f'Hi, {name} you have successfully registered')
                return redirect('log_in')
        else:
            messages.error(request, 'Passwords do not match')
    return render(request, 'main/register.html')

def log_in(request):
    
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user= authenticate(request, username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('home')
    return render(request,'main/login.html')

def log_out(request):
    logout(request)
    return redirect('log_in')

@login_required(login_url='log_in')
def change_password(request):
    cf=PasswordChangeForm(user= request.user)
    if request.method == 'POST':
        cf=PasswordChangeForm(user=request.user,data=request.POST)
        if cf.is_valid():
            cf.save()
            return redirect('log_in')
    return render(request,'main/change_password.html',{'cf':cf})

    