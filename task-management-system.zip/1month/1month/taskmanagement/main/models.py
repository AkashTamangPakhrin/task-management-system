from django.db import models

# Create your models here.
class Project(models.Model):
    name=models.CharField(max_length=30)
    age=models.IntegerField()
    email=models.EmailField()
    message=models.TextField()
    Isdelete=models.BooleanField(default=False)
    