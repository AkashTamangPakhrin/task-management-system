from django.urls import path 
from .views import *

urlpatterns = [
    path("",home,name="home"),
    path("aboutus/",aboutus,name="aboutus"),
    path("about/",about,name="about"),
    path("form/",form,name="form"),
    path("update/",update,name="update"),
    path("track/",track,name="track"),
    path("create/",create,name="create"),
    path("search/",search_form,name="search_form"),
    path("delete/<int:id>",delete_data,name="delete_data"),
    path("edit/<int:id>",edit,name="edit"),
    path("register",register,name="register"),
    path("login/",log_in,name="log_in"),
    path("logout/",log_out,name="log_out"),
]
