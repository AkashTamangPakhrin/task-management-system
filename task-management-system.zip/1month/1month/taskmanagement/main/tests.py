from django.test import TestCase

# Create your tests here.
# 41:39
# day 33
# 24:43
# day 29 45:17
# day:30 19:27